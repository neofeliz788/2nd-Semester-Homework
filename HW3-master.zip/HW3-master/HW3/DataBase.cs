﻿using MySql.Data.MySqlClient;


namespace HW3
{
    internal class DataBase
    {
       
        public MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;username=root;password=parol;database=hotel");

       
        public void OpenConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }


        public void CloseConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public MySqlConnection GetConnection()
        {
            return connection;
        }
    }
}